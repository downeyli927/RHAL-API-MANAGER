#ifndef _RHAL_WDOG_H_
#define _RHAL_WDOG_H_

#include <rhal_common.h>

#ifdef __cplusplus
extern "C"
{
#endif

/*----------------------------------------------------------------------------------------
  Constants, macros, and type definitions
----------------------------------------------------------------------------------------*/

#ifndef BIT
#define BIT(x)                          (1 <<x)
#endif
#define LAST_BOOT_REASON_SOFTWARE BIT(2)       //last boot reason is software-induced reset
#define LAST_BOOT_REASON_BUTTION  BIT(3)       //last boot reason is reset button press
#define LAST_BOOT_REASON_POWER    BIT(4)       //last boot reason is power cycle  
#define LAST_BOOT_REASON_WATCHDOG BIT(5)       //last boot reason is watchdog expiration  

/*----------------------------------------------------------------------------------------
  Enums and struct definitions
----------------------------------------------------------------------------------------*/

 /**
 * @brief a series of constants related to watchdog operations
 * @name RHAL_WDOG_OPERATE_T
 * @note RHAL_WDOG_ON_WITH_KERNEL_AUTO_KICK can not used to monitor AP crash issue.
 */
typedef enum{
    RHAL_WDOG_ON = 0,                     /**< Turn on the watchdog timer,and need AP kick watchdog periodically. */
    RHAL_WDOG_OFF,                        /**< Turn off the watchdog timer. */
    RHAL_WDOG_KICK,                       /**< Kick watchdog. */
    RHAL_WDOG_ON_WITH_KERNEL_AUTO_KICK,   /**< Turn on the watchdog timer,and kernel will kick watchdog by itself. */
    RHAL_WDOG_HW_RESET,
    RHAL_WDOG_SW_RESET,
    RHAL_AP_WDOG_ON,
    RHAL_AP_WDOG_OFF,
    RHAL_AP_WDOG_KICK,
    RHAL_WDOG_OPERATE_MAX
}RHAL_WDOG_OPERATE_T;

 /**
 * @brief describes different states of the watchdog
 * @name RHAL_WDOG_OPERATE_T
 */
typedef enum{
    RHAL_WDOG_IS_ON_NEED_AP_KICK = 0,          /**< watchdog is enabled. In this case need AP kick watchdog periodically. */
    RHAL_WDOG_IS_OFF,                          /**< watchdog is disabled. */
    RHAL_WDOG_IS_ON_WITH_KERNEL_AUTO_KICK,     /**< watchdog is enabled. In this case kernel will kick watchdog by itself. */
    RHAL_WDOG_STATUS_MAX
}RHAL_WDOG_STATUS_T;


/*----------------------------------------------------------------------------------------
  Function declarations and inline functions
----------------------------------------------------------------------------------------*/

 /**
 * @brief use for enable/disable/kick watchdog
 *
 * @param[in]	operate:cmd used to operate watchdog
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_Operate(RHAL_WDOG_OPERATE_T operate);

 /**
 * @brief use for set watchdog timeout value
 *
 * @param[in]	p_timeout:buff for timeout value
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_SetTimeout(UINT32 *p_timeout);

 /**
 * @brief use for set watchdog timeout value
 *
 * @param[out]	p_timeout:buff for timeout value
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_GetTimeout(UINT32 *p_timeout);

 /**
 * @brief use for set watchdog NMI timeout value
 *
 * @param[in]	p_timeout:buff for timeout value
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_SetPreTimeout(UINT32 *p_timeout);

 /**
 * @brief use for get watchdog NMI timeout value
 *
 * @param[in]	p_timeout:buff for timeout value
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_GetPreTimeout(UINT32 *p_timeout);

 /**
 * @brief use for get left time before watchdog timeout.
 *
 * @param[out]	p_timeleft:buff for timeleft
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_GetTimeLeft(UINT32 *p_timeleft);

 /**
 * @brief use for get watchdog status.
 *
 * @param[out]	p_status:buff for watchdog status
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_GetStatus(RHAL_WDOG_STATUS_T* p_status);

 /**
 * @brief use for get watchdog last boot status.
 *
 * @param[out]	p_status:buff for watchdog last boot status
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_WDOG_GetLastBootStatus(int* p_status);

 /**
 * @brief use open ap watchdog.
 *
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_SET_AP_WDOG_ON(void);

 /**
 * @brief use close ap watchdog.
 *
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_SET_AP_WDOG_OFF(void);

 /**
 * @brief use kick ap watchdog.
 *
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
DTV_STATUS_T RHAL_AP_WDOG_KEEPALIVE(void);

 /**
 * @brief set ap id.
 *
 * @param[out]	ap_id:ap id
 * @return  DTV_STATUS_T
 * @retval	API_OK
 * @retval	API_NOT_OK
 */
void RHAL_AP_WDOG_SET_ID(UINT32 ap_id);

#ifdef __cplusplus
}
#endif

#endif  /* _RHAL_WDOG_H_ */
