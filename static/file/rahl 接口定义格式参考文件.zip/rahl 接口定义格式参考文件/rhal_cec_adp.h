#ifndef _RHAL_CEC_ADP_H_
#define _RHAL_CEC_ADP_H_

#ifdef __cplusplus
extern "C" {
#endif


#include <rhal_common.h>

/*----------------------------------------------------------------------------------------
  Constants, macros, and type definitions
----------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------
  Enums and struct definitions
----------------------------------------------------------------------------------------*/

/**
 * @brief status of cec message
 * @name HAL_CEC_STS
 */
typedef enum
{
    HAL_CEC_STS_OK   =  0,
    HAL_CEC_STS_FAIL = -1,
}HAL_CEC_STS;

/**
 * @brief cec message structure
 * @name HAL_CEC_MSG
 */
typedef struct _RHAL_CEC_MSG
{
    unsigned char*      Buff;
    unsigned char       Len;
} HAL_CEC_MSG;

/*----------------------------------------------------------------------------------------
  Function declarations and inline functions
----------------------------------------------------------------------------------------*/

/**
 * @brief Open a RTK CEC Adapter
 *
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_Open(void);

/**
 * @brief Close a RTK CEC Adapter
 *
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_Close(void);

/**
 * @brief Open a RTK CEC Adapter
 *
 * @param[in]	pMsg:Message to submit
 * @param[in]	Len:Message length
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_SendMessage( UINT8* pMsg, UINT8 Len );

/**
 * @brief Read a CEC Message onto CEC Bus
 *
 * @param[out]	pMsg:Received Message
 * @param[in]	Len:The length of message buf
 * @param[out]	pRxLen:An output parameter pointer used to return the number of bytes actually read
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_ReadMessage( UINT8* pMsg, UINT8 Len, UINT8 *pRxLen);

/**
 * @brief Send Poll Message onto CEC Bus
 *
 * @param[in]	Dest:The address of the device being polled
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_PollDevice( UINT8 Dest);

/**
 * @brief Enable CEC Adapter
 *
 * @param[in]	OnOff:0 : off, others : on
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_Enable ( UINT8 OnOff );

/**
 * @brief Set Logical address of CEC Adapter
 *
 * @param[in]	LogicalAddr:logical address of CEC adapter
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_SetLogicalAddress (UINT8 LogicalAddr);

/**
 * @brief Set retry times of rtd cec
 *
 * @param[in]	Num:Retry times
 * @return  HAL_CEC_STS
 * @retval	HAL_CEC_STS_OK
 * @retval	HAL_CEC_STS_FAIL
 */
HAL_CEC_STS RHAL_CEC_ADP_SetRetryNum(UINT8 Num);

/* invalid*/
//HAL_CEC_STS RHAL_CEC_ADP_HdmiPortSupportARC(SINT32* ArcPort);
//Use RHAL_VFE_HDMI_GetARCChannel

#ifdef __cplusplus
}
#endif

#endif /*_RHAL_CEC_ADP_H_ */

